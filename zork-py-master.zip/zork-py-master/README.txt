Thank you for downloading a copy of Zork, The PY Edition!
This Python Program is based loosely on the Storyline of Zork I, and is intended to run and function exactly like the original -
the only difference being that this version is written with Python and can therefore be run and downloaded for free!

To get started:
1. Unzip/Extract the files within this folder to your computer
2. If you do not have the latest version of Python installed, please install it from http://www.python.org/download
3. Open the file named "zork.py"
4. Have Fun!


Copyright (c) 2014 Billy Burrows
